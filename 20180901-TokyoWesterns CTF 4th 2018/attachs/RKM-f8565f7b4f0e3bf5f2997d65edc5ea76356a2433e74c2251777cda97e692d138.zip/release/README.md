# Readable Kernel Module

I don't have enough skill for writing kernel exploiting challenge X(

So I (almost) copy&pasted run.sh/init from other kernel exploit challenges, and copy&pasted source code from past CSAW CTF. ( https://github.com/mncoppola/StringIPC/blob/master/main.c ) 

Because copy&paste is easy.

Then I patched the bug as below (I should publish source code, cuz csaw's source code is GPL :) ).

So it's unexploitable.

Can you still steal my flag?

FYI) You can use `wget` command to download your exploit (No need to copy&paste binary).
